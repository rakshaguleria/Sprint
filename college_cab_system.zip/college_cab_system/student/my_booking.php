<?php
session_start();
require "../config/db.php";

// Redirect if not logged in or not a student
if(!isset($_SESSION['user_id']) || $_SESSION['role'] != 'student'){
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch all bookings for this student
$stmt = $conn->prepare("
    SELECT b.booking_id, c.registration_no, b.pickup_time, b.drop_time, b.pickup_point, b.drop_point, b.status 
    FROM bookings b
    LEFT JOIN cabs c ON b.cab_id = c.cab_id
    WHERE b.user_id=?
    ORDER BY b.pickup_time DESC
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$bookings = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>My Bookings - Student</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php include "../includes/header.php"; ?>

<div class="container mt-5">
    <h2 class="mb-4">My Bookings</h2>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Booking ID</th>
                <th>Cab Number</th>
                <th>Pickup Point</th>
                <th>Drop Point</th>
                <th>Pickup Time</th>
                <th>Drop Time</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php if($bookings->num_rows > 0): ?>
                <?php while($row = $bookings->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['booking_id'] ?></td>
                    <td><?= $row['registration_no'] ?></td>
                    <td><?= $row['pickup_point'] ?></td>
                    <td><?= $row['drop_point'] ?></td>
                    <td><?= date("d M Y, h:i A", strtotime($row['pickup_time'])) ?></td>
                    <td><?= date("d M Y, h:i A", strtotime($row['drop_time'])) ?></td>
                    <td><?= ucfirst($row['status']) ?></td>
                </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="7" class="text-center">No bookings found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include "../includes/footer.php"; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
