<?php
session_start();
require "../config/db.php";

// Redirect if not logged in or not a student
if(!isset($_SESSION['user_id']) || $_SESSION['role'] != 'student'){
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$success = $error = "";

// Handle form submission
if(isset($_POST['book_cab'])){

    $cab_id = $_POST['cab_id'];
    $pickup_time = $_POST['pickup_time'];
    $pickup_point = $_POST['pickup_point'];
    $drop_point = $_POST['drop_point'];

    if($pickup_point == $drop_point){
        $error = "Pickup and drop points cannot be the same!";
    } else {

        $stmt = $conn->prepare("INSERT INTO bookings 
        (user_id, cab_id, pickup_time, pickup_point, drop_point, status) 
        VALUES (?, ?, ?, ?, ?, 'pending')");

        $stmt->bind_param("iisss", $user_id, $cab_id, $pickup_time, $pickup_point, $drop_point);

        if($stmt->execute()){
            $success = "Cab booked successfully!";
        } else {
            $error = "Booking failed. Please try again.";
        }
    }
}

// Fetch available cabs
$cabs = $conn->query("SELECT * FROM cabs WHERE status='available'");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Book Cab - Student</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include "../includes/header.php"; ?>

<div class="container mt-5">
    <h2 class="mb-4">Book a Cab</h2>

    <?php if($success) echo "<div class='alert alert-success'>$success</div>"; ?>
    <?php if($error) echo "<div class='alert alert-danger'>$error</div>"; ?>

    <form method="post">

        <!-- Select Cab -->
        <div class="mb-3">
            <label>Select Cab</label>
            <select name="cab_id" class="form-select" required>
                <option value="">-- Select Cab --</option>
                <?php while($cab = $cabs->fetch_assoc()){ ?>
                    <option value="<?php echo $cab['cab_id']; ?>">
                        <?php echo $cab['registration_no'] . " (Capacity: " . $cab['capacity'] . ")"; ?>
                    </option>
                <?php } ?>
            </select>
        </div>

        <!-- Pickup Time Slot -->
        <div class="mb-3">
            <label>Select Time Slot</label>
            <select name="pickup_time" class="form-select" required>
                <option value="">-- Select Time Slot --</option>
                <option value="08:30 AM">08:30 AM (Morning Pickup)</option>
                <option value="12:30 PM">12:30 PM (Mid-Day Pickup)</option>
                <option value="04:30 PM">04:30 PM (Evening Return)</option>
            </select>
        </div>

        <!-- Pickup Point -->
        <div class="mb-3">
            <label>Pickup Point</label>
            <select name="pickup_point" class="form-select" required>
                <option value="">-- Select Pickup Point --</option>
                <option value="Zero Point">Zero Point</option>
                <option value="LR">LR</option>
                <option value="Shoolini University">Shoolini University</option>
            </select>
        </div>

        <!-- Drop Point -->
        <div class="mb-3">
            <label>Drop Point</label>
            <select name="drop_point" class="form-select" required>
                <option value="">-- Select Drop Point --</option>
                <option value="Zero Point">Zero Point</option>
                <option value="LR">LR</option>
                <option value="Shoolini University">Shoolini University</option>
            </select>
        </div>

        <button type="submit" name="book_cab" class="btn btn-success">Book Cab</button>

    </form>
</div>

<?php include "../includes/footer.php"; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>