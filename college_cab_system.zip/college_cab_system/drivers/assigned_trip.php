<?php
session_start();
require "../config/db.php";

if(!isset($_SESSION['user_id']) || $_SESSION['role'] != 'driver'){
    header("Location: ../login.php");
    exit();
}

$driver_id = $_SESSION['user_id'];

// Fetch trips assigned to this driver
$stmt = $conn->prepare("
    SELECT b.booking_id, u.name as student_name, c.registration_no, b.pickup_time, b.drop_time, b.status
    FROM bookings b
    JOIN cabs c ON b.cab_id=c.cab_id
    JOIN users u ON b.user_id=u.user_id
    WHERE c.driver_id=?
    ORDER BY b.pickup_time DESC
");
$stmt->bind_param("i", $driver_id);
$stmt->execute();
$trips = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Assigned Trips</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<?php include "../includes/header.php"; ?>

<div class="container mt-5">
    <h2 class="mb-4">Assigned Trips</h2>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Booking ID</th>
                <th>Student Name</th>
                <th>Cab Number</th>
                <th>Pickup Time</th>
                <th>Drop Time</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if($trips->num_rows > 0){ ?>
                <?php while($row = $trips->fetch_assoc()){ ?>
                <tr>
                    <td><?php echo $row['booking_id']; ?></td>
                    <td><?php echo $row['student_name']; ?></td>
                    <td><?php echo $row['registration_no']; ?></td>
                    <td><?php echo $row['pickup_time']; ?></td>
                    <td><?php echo $row['drop_time']; ?></td>
                    <td><?php echo ucfirst($row['status']); ?></td>
                    <td>
                        <?php if($row['status'] != 'completed'){ ?>
                            <a href="update_trip_status.php?id=<?php echo $row['booking_id']; ?>&status=completed" class="btn btn-success btn-sm">Complete</a>
                            <a href="update_trip_status.php?id=<?php echo $row['booking_id']; ?>&status=cancelled" class="btn btn-danger btn-sm">Cancel</a>
                        <?php } else { ?>
                            <span class="text-success">Done</span>
                        <?php } ?>
                    </td>
                </tr>
                <?php } ?>
            <?php } else { ?>
                <tr><td colspan="7" class="text-center">No trips assigned.</td></tr>
            <?php } ?>
        </tbody>
    </table>
</div>

<?php include "../includes/footer.php"; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
