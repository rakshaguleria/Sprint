<?php
session_start();
require "../config/db.php";

if(!isset($_SESSION['user_id']) || $_SESSION['role'] != 'driver'){
    header("Location: ../login.php");
    exit();
}

$driver_id = $_SESSION['user_id'];

if(isset($_GET['id']) && isset($_GET['status'])){
    $booking_id = $_GET['id'];
    $status = $_GET['status'];

    // Update booking status
    $stmt = $conn->prepare("
        UPDATE bookings 
        SET status=? 
        WHERE booking_id=? AND cab_id IN (SELECT cab_id FROM cabs WHERE driver_id=?)
    ");
    $stmt->bind_param("sii", $status, $booking_id, $driver_id);
    $stmt->execute();
}

header("Location: assigned_trips.php");
exit();
?>
