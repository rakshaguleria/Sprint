<?php
session_start();
require "../config/db.php";

if(!isset($_SESSION['user_id']) || $_SESSION['role'] != 'driver'){
    header("Location: ../login.php");
    exit();
}

$driver_id = $_SESSION['user_id'];
$success = $error = "";

// Submit complaint
if(isset($_POST['submit_complaint'])){
    $title = $_POST['title'];
    $description = $_POST['description'];

    if(empty($title) || empty($description)){
        $error = "Please fill all fields.";
    } else {
        $stmt = $conn->prepare("INSERT INTO complaints (user_id, role, title, description, status) VALUES (?, 'driver', ?, ?, 'Pending')");
        $stmt->bind_param("iss", $driver_id, $title, $description);

        if($stmt->execute()){
            $success = "Complaint submitted successfully!";
        } else {
            $error = "Failed to submit complaint.";
        }
    }
}

// Fetch driver's complaints
$complaints = $conn->query("SELECT * FROM complaints WHERE user_id=$driver_id AND role='driver' ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Driver Complaints</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<?php include "../includes/header.php"; ?>

<div class="container mt-5">
    <h2 class="mb-4">Submit Complaint</h2>

    <?php if($success) echo "<div class='alert alert-success'>$success</div>"; ?>
    <?php if($error) echo "<div class='alert alert-danger'>$error</div>"; ?>

    <form method="post">
        <div class="mb-3">
            <label>Title</label>
            <input type="text" name="title" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Description</label>
            <textarea name="description" class="form-control" rows="5" required></textarea>
        </div>
        <button type="submit" name="submit_complaint" class="btn btn-primary">Submit</button>
    </form>

    <h3 class="mt-5">My Complaints</h3>
    <table class="table table-bordered mt-2">
        <thead>
            <tr>
                <th>ID</th>
                <th>Title</th>
                <th>Description</th>
                <th>Status</th>
                <th>Submitted On</th>
            </tr>
        </thead>
        <tbody>
            <?php if($complaints->num_rows > 0){ ?>
                <?php while($row = $complaints->fetch_assoc()){ ?>
                    <tr>
                        <td><?php echo $row['complaint_id']; ?></td>
                        <td><?php echo $row['title']; ?></td>
                        <td><?php echo $row['description']; ?></td>
                        <td><?php echo $row['status']; ?></td>
                        <td><?php echo $row['created_at']; ?></td>
                    </tr>
                <?php } ?>
            <?php } else { ?>
                <tr><td colspan="5" class="text-center">No complaints found.</td></tr>
            <?php } ?>
        </tbody>
    </table>
</div>

<?php include "../includes/footer.php"; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
