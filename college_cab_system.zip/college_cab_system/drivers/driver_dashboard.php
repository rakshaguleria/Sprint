<?php
session_start();
require "../config/db.php";

if(!isset($_SESSION['user_id']) || $_SESSION['role'] != 'driver'){
    header("Location: ../login.php");
    exit();
}

$driver_id = $_SESSION['user_id'];

// Count assigned trips
$stmt = $conn->prepare("SELECT COUNT(*) as total FROM bookings WHERE cab_id IN (SELECT cab_id FROM cabs WHERE driver_id=?) AND status='pending'");
$stmt->bind_param("i", $driver_id);
$stmt->execute();
$totalTrips = $stmt->get_result()->fetch_assoc()['total'];

// Count completed trips
$stmt = $conn->prepare("SELECT COUNT(*) as completed FROM bookings WHERE cab_id IN (SELECT cab_id FROM cabs WHERE driver_id=?) AND status='completed'");
$stmt->bind_param("i", $driver_id);
$stmt->execute();
$completedTrips = $stmt->get_result()->fetch_assoc()['completed'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Driver Dashboard</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<?php include "../includes/header.php"; ?>

<div class="container mt-5">
    <h2 class="mb-4">Driver Dashboard</h2>

    <div class="row">
        <div class="col-md-6">
            <div class="card text-center">
                <div class="card-body">
                    <h5 class="card-title">Pending Trips</h5>
                    <p class="card-text display-4"><?php echo $totalTrips; ?></p>
                    <a href="assigned_trips.php" class="btn btn-primary">View Trips</a>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card text-center">
                <div class="card-body">
                    <h5 class="card-title">Completed Trips</h5>
                    <p class="card-text display-4"><?php echo $completedTrips; ?></p>
                    <a href="assigned_trips.php" class="btn btn-primary">View Trips</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include "../includes/footer.php"; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
