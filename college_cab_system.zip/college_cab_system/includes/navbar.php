<?php
if(session_status() == PHP_SESSION_NONE){
    session_start();
}

$base_url = "/college_cab_system"; // <- YOUR PROJECT FOLDER
$current_page = basename($_SERVER['PHP_SELF']);
?>
<nav class="navbar navbar-expand-lg shadow-sm custom-navbar">
  <div class="container">
    <a class="navbar-brand" href="<?= $base_url ?>/index.php">Shoolini Go</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="<?= $base_url ?>/index.php">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= $base_url ?>/about.php">About</a></li>

        <?php if(isset($_SESSION['user_id'])): ?>
            <?php if($_SESSION['role']=='student'): ?>
              <li class="nav-item"><a class="nav-link" href="<?= $base_url ?>/student/book_cab.php">Book Cab</a></li>
              <li class="nav-item"><a class="nav-link" href="<?= $base_url ?>/student/my_booking.php">My Bookings</a></li>
              <li class="nav-item"><a class="nav-link" href="<?= $base_url ?>/student/complaint.php">Complaints</a></li>
            <?php elseif($_SESSION['role']=='drivers'): ?>
              <li class="nav-item"><a class="nav-link" href="<?= $base_url ?>/drivers/driver_dashboard.php">Dashboard</a></li>
              <li class="nav-item"><a class="nav-link" href="<?= $base_url ?>/drivers/assigned_trip.php">Trips</a></li>
              <li class="nav-item"><a class="nav-link" href="<?= $base_url ?>/drivers/driver_complaint.php">Complaints</a></li>
            <?php elseif($_SESSION['role']=='admin'): ?>
              <li class="nav-item"><a class="nav-link" href="<?= $base_url ?>/admin/admin_dashboard.php">Admin Dashboard</a></li>
              <li class="nav-item"><a class="nav-link" href="<?= $base_url ?>/admin/manage_users.php">Manage Users</a></li>
              <li class="nav-item"><a class="nav-link" href="<?= $base_url ?>/admin/manage_cabs.php">Manage Cabs</a></li>
              <li class="nav-item"><a class="nav-link" href="<?= $base_url ?>/admin/all_booking.php">Bookings</a></li>
              <li class="nav-item"><a class="nav-link" href="<?= $base_url ?>/admin/all_complaints.php">Complaints</a></li>
            <?php endif; ?>
            <li class="nav-item"><a class="nav-link" href="<?= $base_url ?>/logout.php">Logout</a></li>
        <?php else: ?>
            <li class="nav-item"><a class="nav-link" href="<?= $base_url ?>/login.php">Login</a></li>
            <li class="nav-item"><a class="nav-link" href="<?= $base_url ?>/register.php">Register</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>
