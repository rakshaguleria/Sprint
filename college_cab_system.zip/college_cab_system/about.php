<?php include "includes/header.php"; ?>

<div class="container mt-5">
    <h2>About College Cab System</h2>
    <p>This web application is designed to help college students book cabs, drivers manage trips, and administrators manage users, cabs, bookings, and complaints efficiently. It provides a complete workflow for the college transportation system with real-time booking and complaint tracking.</p>

    <h4>Features:</h4>
    <ul>
        <li>Student can book cabs and view their bookings.</li>
        <li>Driver can view assigned trips and update status.</li>
        <li>Admin can manage users, cabs, bookings, and complaints.</li>
        <li>Complaint system for both students and drivers.</li>
    </ul>
</div>

<?php include "includes/footer.php"; ?>
