<?php
include "includes/header.php";
require "config/db.php"; // database connection

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name     = trim($_POST['name']);
    $email    = trim($_POST['email']);
    $password = trim($_POST['password']);
    $role     = $_POST['role']; // student/driver

    // Basic validation
    if (empty($name) || empty($email) || empty($password) || empty($role)) {
        $error = "All fields are required!";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email address!";
    } else {
        // Check if user already exists
        $stmt = $conn->prepare("SELECT * FROM users WHERE email=?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        if($result->num_rows > 0) {
            $error = "Email already registered!";
        } else {
            // Insert new user
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $name, $email, $hashed_password, $role);
            if($stmt->execute()) {
                $success = "Registration successful! You can <a href='login.php'>login</a> now.";
            } else {
                $error = "Something went wrong! Try again.";
            }
        }
    }
}
?>

<div class="container mt-5">
    <div class="form-section mx-auto" style="max-width: 500px;">
        <h3 class="text-center mb-4">Register</h3>

        <?php if($error): ?>
            <div class="alert alert-danger"><?= $error ?></div>
        <?php endif; ?>

        <?php if($success): ?>
            <div class="alert alert-success"><?= $success ?></div>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="mb-3">
                <label for="name" class="form-label">Full Name</label>
                <input type="text" name="name" id="name" class="form-control" required value="<?= isset($name)?htmlspecialchars($name):'' ?>">
            </div>

            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" name="email" id="email" class="form-control" required value="<?= isset($email)?htmlspecialchars($email):'' ?>">
            </div>

            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" name="password" id="password" class="form-control" required>
            </div>

            <div class="mb-3">
                <label for="role" class="form-label">Role</label>
                <select name="role" id="role" class="form-control" required>
                    <option value="">Select Role</option>
                    <option value="student" <?= (isset($role) && $role=='student')?'selected':'' ?>>Student</option>
                    <option value="driver" <?= (isset($role) && $role=='driver')?'selected':'' ?>>Driver</option>
                </select>
            </div>

            <div class="text-center">
                <button type="submit" class="btn btn-primary w-100">Register</button>
            </div>

            <p class="mt-3 text-center">Already have an account? <a href="login.php">Login here</a>.</p>
        </form>
    </div>
</div>

<?php include "includes/footer.php"; ?>
