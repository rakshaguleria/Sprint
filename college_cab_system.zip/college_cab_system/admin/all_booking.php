<?php
session_start();
require "../config/db.php";

if(!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin'){
    header("Location: ../login.php");
    exit();
}

// Fetch all bookings
$stmt = $conn->prepare("
    SELECT b.booking_id, u.name as student_name, c.registration_no, b.pickup_time, b.drop_time, b.status
    FROM bookings b
    JOIN users u ON b.user_id=u.user_id
    JOIN cabs c ON b.cab_id=c.cab_id
    ORDER BY b.pickup_time DESC
");
$stmt->execute();
$bookings = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>All Bookings - Admin</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<?php include "../includes/header.php"; ?>

<div class="container mt-5">
    <h2 class="mb-4">All Bookings</h2>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Student Name</th>
                <th>Cab Number</th>
                <th>Pickup Time</th>
                <th>Drop Time</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php if($bookings->num_rows > 0){ ?>
                <?php while($row = $bookings->fetch_assoc()){ ?>
                    <tr>
                        <td><?php echo $row['booking_id']; ?></td>
                        <td><?php echo $row['student_name']; ?></td>
                        <td><?php echo $row['registration_no']; ?></td>
                        <td><?php echo $row['pickup_time']; ?></td>
                        <td><?php echo $row['drop_time']; ?></td>
                        <td><?php echo ucfirst($row['status']); ?></td>
                    </tr>
                <?php } ?>
            <?php } else { ?>
                <tr><td colspan="6" class="text-center">No bookings found.</td></tr>
            <?php } ?>
        </tbody>
    </table>
</div>

<?php include "../includes/footer.php"; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
