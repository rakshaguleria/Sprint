<?php
session_start();
require "../config/db.php";

if(!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin'){
    header("Location: ../login.php");
    exit();
}

$success = $error = "";

// Add Cab
if(isset($_POST['add_cab'])){
    $reg_no = $_POST['registration_no'];
    $capacity = $_POST['capacity'];
    $driver_id = $_POST['driver_id'];

    $stmt = $conn->prepare("INSERT INTO cabs (registration_no, driver_id, capacity, status) VALUES (?,?,?, 'available')");
    $stmt->bind_param("sii", $reg_no, $driver_id, $capacity);
    if($stmt->execute()) $success = "Cab added successfully";
    else $error = "Failed to add cab";
}

// Fetch cabs
$cabs = $conn->query("SELECT c.*, u.name as driver_name FROM cabs c LEFT JOIN users u ON c.driver_id=u.user_id ORDER BY c.cab_id DESC");

// Fetch drivers
$drivers = $conn->query("SELECT * FROM users WHERE role='driver'");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Manage Cabs - Admin</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<?php include "../includes/header.php"; ?>

<div class="container mt-5">
    <h2 class="mb-4">Manage Cabs</h2>

    <?php if($success) echo "<div class='alert alert-success'>$success</div>"; ?>
    <?php if($error) echo "<div class='alert alert-danger'>$error</div>"; ?>

    <form method="post" class="mb-4 row g-3">
        <div class="col-md-3"><input type="text" name="registration_no" placeholder="Registration No" class="form-control" required></div>
        <div class="col-md-2"><input type="number" name="capacity" placeholder="Capacity" class="form-control" required></div>
        <div class="col-md-3">
            <select name="driver_id" class="form-select" required>
                <option value="">Assign Driver</option>
                <?php while($d = $drivers->fetch_assoc()){ ?>
                    <option value="<?php echo $d['user_id']; ?>"><?php echo $d['name']; ?></option>
                <?php } ?>
            </select>
        </div>
        <div class="col-md-2"><button type="submit" name="add_cab" class="btn btn-primary w-100">Add Cab</button></div>
    </form>

    <table class="table table-bordered">
        <thead>
            <tr><th>ID</th><th>Registration No</th><th>Driver</th><th>Capacity</th><th>Status</th></tr>
        </thead>
        <tbody>
            <?php while($row = $cabs->fetch_assoc()){ ?>
                <tr>
                    <td><?php echo $row['cab_id']; ?></td>
                    <td><?php echo $row['registration_no']; ?></td>
                    <td><?php echo $row['driver_name']; ?></td>
                    <td><?php echo $row['capacity']; ?></td>
                    <td><?php echo ucfirst($row['status']); ?></td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

<?php include "../includes/footer.php"; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
