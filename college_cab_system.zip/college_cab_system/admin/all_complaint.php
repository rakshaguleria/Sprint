<?php
session_start();
require "../config/db.php";

if(!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin'){
    header("Location: ../login.php");
    exit();
}

// Handle status update
if(isset($_GET['id']) && isset($_GET['status'])){
    $stmt = $conn->prepare("UPDATE complaints SET status=? WHERE complaint_id=?");
    $stmt->bind_param("si", $_GET['status'], $_GET['id']);
    $stmt->execute();
}

// Fetch all complaints
$complaints = $conn->query("SELECT c.*, u.name as user_name FROM complaints c JOIN users u ON c.user_id=u.user_id ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>All Complaints - Admin</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php include "../includes/header.php"; ?>

<div class="container mt-5">
    <h2 class="mb-4">All Complaints</h2>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>User</th>
                <th>Role</th>
                <th>Title</th>
                <th>Description</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if($complaints->num_rows > 0){ ?>
                <?php while($row = $complaints->fetch_assoc()){ ?>
                    <tr>
                        <td><?php echo $row['complaint_id']; ?></td>
                        <td><?php echo $row['user_name']; ?></td>
                        <td><?php echo $row['role']; ?></td>
                        <td><?php echo $row['title']; ?></td>
                        <td><?php echo $row['description']; ?></td>
                        <td><?php echo $row['status']; ?></td>
                        <td>
                            <?php if($row['status'] != 'Resolved'){ ?>
                                <a href="all_complaints.php?id=<?php echo $row['complaint_id']; ?>&status=Resolved" class="btn btn-success btn-sm">Mark Resolved</a>
                            <?php } else { echo "Resolved"; } ?>
                        </td>
                    </tr>
                <?php } ?>
            <?php } else { ?>
                <tr><td colspan="7" class="text-center">No complaints found.</td></tr>
            <?php } ?>
        </tbody>
    </table>
</div>

<?php include "../includes/footer.php"; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
