<?php include "includes/header.php"; ?>

<div class="container mt-5">
    <div class="jumbotron text-center bg-light p-5 rounded">
        <h1 class="display-4">Welcome to College Cab System</h1>
        <p class="lead">Book your college cab easily, track your bookings, and submit complaints if needed.</p>

        <?php if(!isset($_SESSION['user_id'])): ?>
            <a href="login.php" class="btn btn-primary btn-lg">Login</a>
            <a href="register.php" class="btn btn-secondary btn-lg">Register</a>
        <?php else: ?>
            <p class="mt-3">You are logged in as <strong><?php echo $_SESSION['role']; ?></strong>.</p>
        <?php endif; ?>
    </div>

    <div class="row mt-5 text-center">
        <div class="col-md-4">
            <i class="bi bi-car-front-fill display-1 text-primary"></i>
            <h3>Book Cab</h3>
            <p>Students can easily book available cabs for their college commute.</p>
        </div>
        <div class="col-md-4">
            <i class="bi bi-person-lines-fill display-1 text-primary"></i>
            <h3>Driver Management</h3>
            <p>Drivers can view their assigned trips and update trip status in real-time.</p>
        </div>
        <div class="col-md-4">
            <i class="bi bi-clipboard-check-fill display-1 text-primary"></i>
            <h3>Complaint System</h3>
            <p>Students and drivers can submit complaints and track their status.</p>
        </div>
    </div>
</div>

<?php include "includes/footer.php"; ?>

